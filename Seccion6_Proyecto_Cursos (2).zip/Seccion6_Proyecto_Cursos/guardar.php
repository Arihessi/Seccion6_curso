<?php
require __DIR__ . '/conexion.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método no permitido.');
}
$nombre = trim($_POST['nombre'] ?? '');
$docente = trim($_POST['docente'] ?? '');
$duracion = filter_var($_POST['duracion'] ?? null, FILTER_VALIDATE_INT);
$modalidad = $_POST['modalidad'] ?? '';
$validas = ['Presencial', 'Virtual', 'Híbrida'];
if ($nombre === '' || $docente === '' || !$duracion ||
    $duracion < 1 || $duracion > 52 ||
    !in_array($modalidad, $validas, true) ||
    strlen($nombre) > 100 || strlen($docente) > 100) {
    http_response_code(400);
    exit('Datos inválidos. Vuelva al formulario y revise los campos.');
}
$sql = 'INSERT INTO cursos (nombre, docente, duracion, modalidad)
        VALUES (:nombre, :docente, :duracion, :modalidad)';
$sentencia = $pdo->prepare($sql);
$sentencia->execute([
    'nombre' => $nombre,
    'docente' => $docente,
    'duracion' => $duracion,
    'modalidad' => $modalidad,
]);
header('Location: index.php');
exit;