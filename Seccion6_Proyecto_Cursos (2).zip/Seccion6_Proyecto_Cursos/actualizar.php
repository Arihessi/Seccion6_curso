<?php
require_once __DIR__ . '/conexion.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método no permitido.');
}
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
$nombre = trim($_POST['nombre'] ?? '');
$docente = trim($_POST['docente'] ?? '');
$duracion = filter_var($_POST['duracion'] ?? null, FILTER_VALIDATE_INT);
$modalidad = $_POST['modalidad'] ?? '';
if (!$id || $id < 1 || $nombre === '' || $docente === '' || !$duracion || 
    $duracion < 1 || $duracion > 52 || 
    strlen($nombre) > 100 || strlen($docente) > 100 || 
    !in_array($modalidad, ['Presencial', 'Virtual', 'Híbrida'], true)) {
    http_response_code(400);
    exit('Datos inválidos. Regrese al formulario de edición.');
}
$sql = 'UPDATE cursos SET nombre = :nombre, docente = :docente, 
        duracion = :duracion, modalidad = :modalidad WHERE id = :id';
$sentencia = $pdo->prepare($sql);
$sentencia->execute([
    'id' => $id,
    'nombre' => $nombre,
    'docente' => $docente,
    'duracion' => $duracion,
    'modalidad' => $modalidad,
]);
header('Location: index.php');
exit;