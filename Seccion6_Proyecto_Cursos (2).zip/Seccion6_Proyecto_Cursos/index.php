<?php
require __DIR__ . '/conexion.php';
$consulta = $pdo->query('
    SELECT id, nombre, docente, duracion, modalidad 
    FROM cursos ORDER BY id DESC
');
$cursos = $consulta->fetchAll();

function escapar($valor) {
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de cursos | PHP y MySQL</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<main class="contenedor">
    <header>
        <h1>Gestión de cursos</h1>
        <p>Sección 6 · PHP + MySQL + PDO</p>
    </header>

    <section class="panel">
        <h2>Registrar un curso</h2>
        <form action="guardar.php" method="POST">
            <label>Nombre del curso
                <input type="text" name="nombre" maxlength="100" required>
            </label>
            <label>Docente
                <input type="text" name="docente" maxlength="100" required>
            </label>
            <label>Duración (semanas)
                <input type="number" name="duracion" min="1" max="52" required>
            </label>
            <label>Modalidad
                <select name="modalidad" required>
                    <option value="Presencial">Presencial</option>
                    <option value="Virtual">Virtual</option>
                    <option value="Híbrida">Híbrida</option>
                </select>
            </label>
            <button type="submit">Guardar curso</button>
        </form>
    </section>

    <section class="panel">
        <h2>Cursos registrados (<?= count($cursos) ?>)</h2>
        <div class="tabla-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Docente</th>
                        <th>Semanas</th>
                        <th>Modalidad</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cursos)): ?>
                        <tr>
                            <td colspan="6">Aún no hay cursos registrados.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($cursos as $curso): ?>
                            <tr>
                                <td><?= escapar($curso['id']) ?></td>
                                <td><?= escapar($curso['nombre']) ?></td>
                                <td><?= escapar($curso['docente']) ?></td>
                                <td><?= escapar($curso['duracion']) ?></td>
                                <td><?= escapar($curso['modalidad']) ?></td>
                                <td class="acciones">
                                    <a href="editar.php?id=<?= (int) $curso['id'] ?>">Editar</a>
                                    <form action="eliminar.php" method="POST" onsubmit="return confirm('¿Eliminar este curso?');">
                                        <input type="hidden" name="id" value="<?= (int) $curso['id'] ?>">
                                        <button type="submit" class="peligro">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
</body>
</html>