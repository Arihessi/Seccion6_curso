<?php
require __DIR__ . '/conexion.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(400);
    exit('Identificador inválido.');
}
$sentencia = $pdo->prepare('
    SELECT id, nombre, docente, duracion, modalidad
    FROM cursos WHERE id = :id
');
$sentencia->execute(['id' => $id]);
$curso = $sentencia->fetch();
if (!$curso) {
    http_response_code(404);
    exit('Curso no encontrado.');
}
function escapar($valor) {
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar curso</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<main class="contenedor panel">
    <h1>Editar curso #<?= (int) $curso['id'] ?></h1>
    <form action="actualizar.php" method="POST">
        <input type="hidden" name="id" value="<?= (int) $curso['id'] ?>">
        <label>Nombre del curso
            <input name="nombre" type="text" maxlength="100"
                   value="<?= escapar($curso['nombre']) ?>" required>
        </label>
        <label>Docente
            <input name="docente" type="text" maxlength="100"
                   value="<?= escapar($curso['docente']) ?>" required>
        </label>
        <label>Duración (semanas)
            <input name="duracion" type="number" min="1" max="52"
                   value="<?= escapar($curso['duracion']) ?>" required>
        </label>
        <label>Modalidad
            <select name="modalidad" required>
                <?php foreach (['Presencial', 'Virtual', 'Híbrida'] as $opcion): ?>
                    <option value="<?= escapar($opcion) ?>"
                        <?= $curso['modalidad'] === $opcion ? 'selected' : '' ?>>
                        <?= escapar($opcion) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit">Guardar cambios</button>
        <a class="volver" href="index.php">Cancelar</a>
    </form>
</main>
</body>
</html>