<?php
require __DIR__ . '/conexion.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
 http_response_code(405);
 exit('Método no permitido.');
}
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
 http_response_code(400);
 exit('Identificador inválido.');
}
$sentencia = $pdo->prepare('DELETE FROM cursos WHERE id = :id');
$sentencia->execute(['id' => $id]);
header('Location: index.php');
exit;
