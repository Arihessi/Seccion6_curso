<?php
// Adaptar usuario y contraseña a la instalación local.
$servidor = 'localhost';
$base = 'web2_cursos';
$usuario = 'root';
$contrasena = ''; // Solo ejemplo de laboratorio local.

try {
    $pdo = new PDO(
        "mysql:host=$servidor;dbname=$base;charset=utf8mb4",
        $usuario,
        $contrasena,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('No fue posible conectar con MySQL. Revise conexion.php.');
}